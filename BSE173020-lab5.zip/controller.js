using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace json.Models
{
    public class Student
    {
        public string Name { get; set; }
        public string Regno { get; set; }
        public string Cgpa { get; set; }
    }
}